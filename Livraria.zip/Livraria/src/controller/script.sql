create table tb_autor(
	id		serial,
	nome	varchar(100) not null,
	constraint pk_autor_id primary key (id)
);

create table tb_livro(
	id			serial,
	titulo		varchar(150) not null,
	ano	integer,
	autor_id integer,
	
	constraint pk_livro_id primary key (id),
	constraint fk_autor_id foreign key (autor_id) references tb_autor(id)

);