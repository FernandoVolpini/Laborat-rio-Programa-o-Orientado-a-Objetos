package controller;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.Autor;

public class AutorDAO {

    private Connection con;
    private PreparedStatement cmd;

    public AutorDAO() {
        con = Conexao.conectar();
    }

    //Inserir um autor na tabela tb_autor
    public int inserir(Autor a) {
        try {
            //Instrução SQL para inserção na tabela
            String SQL = "insert into tb_autor(nome) values (?)";

            //Verficação da sintaxe do SQL
            cmd = con.prepareStatement(SQL, Statement.RETURN_GENERATED_KEYS);

            //Especificação do parâmetro da instrução SQL indicando por "?"
            cmd.setString(1, a.getNome());

            //Executar a instrução SQL
            if (cmd.executeUpdate() > 0) {
                //Retorna o ID o autor inserido
                ResultSet rs = cmd.getGeneratedKeys();
                return rs.next() ? rs.getInt(1) : -1;
            }
            //Retornar -1 se algo de errado ocorreu
            return -1;
        } catch (Exception e) {
            System.err.println("ERRO: " + e.getMessage());
            return -1;
        }
    }

    //
    // ATUALIZAR os dados de um Autor
    //
    public int atualizar(Autor a) {
        try {
            String SQL = "update tb_autor set nome=? where id=?";
            cmd = con.prepareStatement(SQL);
            cmd.setString(1, a.getNome());
            cmd.setInt(2, a.getId());
            return cmd.executeUpdate() > 0 ? a.getId() : -1;
        } catch (Exception e) {
            System.err.println("ERRO: " + e.getMessage());
            return -1;
        }
    }

    //
    // Recuperar todos os Autores da tabela
    //
    public List<Autor> listar() {
        try {
            String SQL = "select * from tb_autor order by nome";
            cmd = con.prepareStatement(SQL);
            ResultSet rs = cmd.executeQuery();
            List<Autor> lista = new ArrayList<>();
            while (rs.next()) {
                Autor a = new Autor(
                        rs.getInt("id"), rs.getString("nome")
                );
                lista.add(a);
            }
            return lista;
        } catch (Exception e) {
            System.err.println("ERRO: " + e.getMessage());
            return null;
        }
    }

    //
    // Recuperar o Autor a partir do ID
    //
    public List<Autor> pesquisarPorId(int id) {
        try {
            String SQL = "select * from tb_autor where id=? order by id";
            cmd = con.prepareStatement(SQL);
            cmd.setInt(1, id);

            ResultSet rs = cmd.executeQuery();
            List<Autor> lista = new ArrayList<>();
            while (rs.next()) {
                Autor a = new Autor(
                        rs.getInt("id"), rs.getString("nome")
                );
                lista.add(a);
            }
            return lista;
        } catch (Exception e) {
            System.err.println("ERRO: " + e.getMessage());
            return null;
        }
    }

    //
    // Recuperar os Autores a partir do NOME
    //
    public List<Autor> pesquisarPorNome(String nome) {
        try {
            String SQL = "select * from tb_autor where nome ilike ? order by id";
            cmd = con.prepareStatement(SQL);
            cmd.setString(1, "%" + nome + "%");

            ResultSet rs = cmd.executeQuery();
            List<Autor> lista = new ArrayList<>();
            while (rs.next()) {
                Autor a = new Autor(
                        rs.getInt("id"), rs.getString("nome")
                );
                lista.add(a);
            }
            return lista;
        } catch (Exception e) {
            System.err.println("ERRO: " + e.getMessage());
            return null;
        }
    }

}
