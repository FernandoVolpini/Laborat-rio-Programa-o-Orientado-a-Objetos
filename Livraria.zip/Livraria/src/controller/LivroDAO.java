package controller;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import model.Livro;

public class LivroDAO {

    private Connection con;
    private PreparedStatement cmd;

    public LivroDAO() {
        con = Conexao.conectar();
    }

    public int inserir(Livro l) {
        try {
            String SQL = "insert into tb_livro (titulo, ano, autor_id) values (?,?,?)";
            cmd = con.prepareStatement(SQL, Statement.RETURN_GENERATED_KEYS);
            cmd.setString(1, l.getTitulo());
            cmd.setInt(2, l.getAno());
            cmd.setInt(3, l.getAutorId());
            if (cmd.executeUpdate() > 0) {
                ResultSet rs = cmd.getGeneratedKeys();
                return rs.next() ? rs.getInt(1) : -1;
            }
            return -1;
        } catch (Exception e) {
            System.err.println("ERRO: " + e.getMessage());
            return -1;
        }
    }

}
