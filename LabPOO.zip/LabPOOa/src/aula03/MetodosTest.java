package aula03;

public class MetodosTest {
    
    public static void main(String[] args) {
        
        Metodos obj = new Metodos();
        obj.testeMetodo1();
        
        // Métodos especificados como STATIC podem
        // ser chamados, sem a necessidade de
        // instanciação de um objeto
        Metodos.testeMetodo3();
    }
    
}
