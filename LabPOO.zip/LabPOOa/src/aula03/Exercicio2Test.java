package aula03;

public class Exercicio2Test {
    
    public static void main(String[] args) {
        Exercicio2 obj = new Exercicio2();
        obj.lerNotas();
        obj.ordenarNotasDecrescente();
        obj.exibirNotas();
        obj.exibirMedia();
    }
}
