package aula03;

import javax.swing.JOptionPane;

public class Exercicio1Test {

    public static void main(String[] args) {

        double idade = Double.parseDouble(
            JOptionPane.showInputDialog("Informe a idade")
        );
        
        Exercicio1 obj = new Exercicio1();
        obj.tipoPessoa(idade);
        
    }
    
}
