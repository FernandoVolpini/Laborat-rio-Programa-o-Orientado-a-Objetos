package aula03;

public class Metodos {

    public void testeMetodo1(){
        System.out.println("Teste Método 1");
    }
    
    private void testeMetodo2(){
        System.out.println("Teste Método 2");
    }

    public static void testeMetodo3(){
        System.out.println("Teste Método 3");
    }
    
}
