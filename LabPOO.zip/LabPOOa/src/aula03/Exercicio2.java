package aula03;

import java.util.Arrays;
import javax.swing.JOptionPane;

public class Exercicio2 {

    double[] notas = new double[5];

    public void lerNotas() {
        for (int i = 0; i < notas.length; i++) {
            double nota = Double.parseDouble(
                    JOptionPane.showInputDialog("Informe a nota " + (i + 1))
            );
            notas[i] = nota;
        }
    }

    public void ordenarNotasDecrescente() {
        Arrays.sort(notas);
        double[] temp = new double[notas.length];
        for (int i = 0; i < notas.length; i++) {
            temp[i] = notas[notas.length - 1 - i];
        }
        notas = Arrays.copyOf(temp, notas.length);
    }
    
    public void exibirNotas(){
        StringBuilder sb = new StringBuilder();
        sb.append("Notas").append("\n");
        for (int i = 0; i < notas.length; i++) {
            sb.append("Nota [").append(i+1).append("]= ").append(notas[i]).append("\n");
        }
         JOptionPane.showMessageDialog(null, sb.toString());
    }
    
    public void exibirMedia(){
        double soma = 0;
        for (int i = 0; i < notas.length; i++) {
            soma += notas[i];
        }
        soma = (soma/notas.length);
        JOptionPane.showMessageDialog(null, "Média: " + soma);
    }

}
