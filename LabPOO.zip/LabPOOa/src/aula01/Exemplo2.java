package aula01;

import javax.swing.JOptionPane;

public class Exemplo2 {
    
    public static void main(String[] args){
        
        String str1 = JOptionPane.showInputDialog(
            "Informe a nota parcial"
        );
        
        String str2 = JOptionPane.showInputDialog(
            "Informe a nota final"
        );
        
        // Converter STRING para DOUBLE
        double np = Double.parseDouble(str1);
        double nf = Double.parseDouble(str2);
        double mf = np*0.40+nf*0.60;
        
        JOptionPane.showMessageDialog(
            null,
            String.format("Média Final: %.2f", mf)
        );
    }
}
