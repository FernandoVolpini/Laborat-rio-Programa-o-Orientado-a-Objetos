package aula01;

import javax.swing.JOptionPane;

public class Exemplo3 {

    public static void main(String[] args) {

        String str1 = JOptionPane.showInputDialog("Nome");
        String str2 = JOptionPane.showInputDialog("Peso");
        String str3 = JOptionPane.showInputDialog("Altura");

        double peso = Double.parseDouble(str2);
        double altura = Double.parseDouble(str3);
        double imc = peso / Math.pow(altura, 2);

        JOptionPane.showMessageDialog(
            null,
            String.format("%s o seu IMC é %.2f", str1, imc),
            "Resultado",
            JOptionPane.ERROR_MESSAGE
        );

    }

}
