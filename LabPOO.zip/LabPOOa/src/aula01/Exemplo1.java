package aula01;

public class Exemplo1 {
    
    public static void main(String[] args){
        
        double np = 7.5;
        double nf = 9.2;
        double mf = np*0.40+nf*0.60;
        
        System.out.printf("Média final %.2f \n", mf);
    }
    
}
