package aula02;

import javax.swing.JOptionPane;

public class JogadasDado {

    public static void main(String[] args) {

        StringBuilder sb = new StringBuilder();
        sb.append("Números sorteados: \n");
        
        int soma = 0;
        for (int i = 1; i <= 3; i++) {
            int num = (int) (Math.random() * 6)+1;
            sb.append(num).append("\n");
            soma += num;
        }
        sb.append("Total = ").append(soma);
        JOptionPane.showMessageDialog(null, sb.toString());

    }
}
