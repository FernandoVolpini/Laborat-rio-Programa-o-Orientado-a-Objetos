package aula02;

public class Matrizes {
    
    public static void main(String[] args) {
        
        int mat[][] = new int[4][4];
        
        //preencher a matriz
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {               
                mat[i][j] = (int)(Math.random()*100);
            }
        }
        
        //visualizar a matriz
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {               
                System.out.print(String.format("%d \t",mat[i][j]));
            }
            System.out.println("");
        }
        
    }
}
