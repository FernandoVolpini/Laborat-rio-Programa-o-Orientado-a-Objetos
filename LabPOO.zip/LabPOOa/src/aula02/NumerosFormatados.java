package aula02;

import java.text.DecimalFormat;

public class NumerosFormatados {
    
    public static void main(String[] args) {
        
        double n1 = Math.random()*10000;
        
        DecimalFormat df = new DecimalFormat();
        df.applyPattern("R$ #,##0.00");
        System.out.println(df.format(n1));        
    }
    
}
