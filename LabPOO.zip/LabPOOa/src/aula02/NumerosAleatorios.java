package aula02;

public class NumerosAleatorios {

    public static void main(String[] args) {
        
        double n1 = Math.random();
        System.out.println("Número: " + n1);
     
        int n2 = (int)(Math.random()*100);
        System.out.println("Número: " + n2);
        
        int n3 = (int)(Math.random()*1000);
        System.out.println("Número: " + n3);
        
    }
    
}
