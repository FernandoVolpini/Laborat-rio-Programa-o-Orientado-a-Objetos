public class TesteLojaEletronicos {
    public static void main(String[] args) {
        Smartphone iphone = new Smartphone("Apple", "iPhone 16 Pro Max", 7999.99, "IOS", 256);
        Laptop macbook = new Laptop("Apple", "MacBook Pro M3", 1200.00, "IOS", 16);
        TV samsungTV = new TV("Samsung", "Neo QLED", 5799.00, 55, "QLED");
        Smartphone xiaomi = new Smartphone("Xiaomi", "Redmi Note 13", 1800.00, "Android", 128);

        System.out.println("Produtos Disponiveis");
        System.out.println(iphone);
        System.out.println(macbook);
        System.out.println(samsungTV);
        System.out.println(xiaomi);

        Cliente joao = new Cliente("Joao Silva", "joao.silva@email.com");
        System.out.println("\nCliente Criado");
        System.out.println(joao);

        CarrinhoDeCompras carrinhoJoao = new CarrinhoDeCompras(joao);

        carrinhoJoao.adicionarProduto(iphone, 1);
        carrinhoJoao.adicionarProduto(macbook, 1);
        carrinhoJoao.adicionarProduto(samsungTV, 2); 
        carrinhoJoao.adicionarProduto(iphone, 1); 

        carrinhoJoao.visualizarCarrinho();

        System.out.println("\n--- Testando ---");
        iphone.setPreco(7500.00);
        System.out.println("Novo preco do iPhone: R$" + String.format("%.2f", iphone.getPreco()));

        macbook.setMemoriaRAMGB(32); 
        System.out.println("Nova RAM do MacBook: " + macbook.getMemoriaRAMGB() + "GB");

        samsungTV.setTamanhoTelaPolegadas(65); 
        System.out.println("Novo tamanho da TV Samsung: " + samsungTV.getTamanhoTelaPolegadas() + " polegadas");

        joao.setEmail("joao.novo.email@provedor.com"); 
        System.out.println("Novo email do Joao: " + joao.getEmail());

        carrinhoJoao.visualizarCarrinho();

        carrinhoJoao.removerProduto(macbook);
        carrinhoJoao.visualizarCarrinho();

        carrinhoJoao.adicionarProduto(xiaomi, 3);
        carrinhoJoao.visualizarCarrinho();
    }
}