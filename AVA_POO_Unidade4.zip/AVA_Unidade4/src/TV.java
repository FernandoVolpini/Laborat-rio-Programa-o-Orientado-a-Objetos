class TV extends Produto {
    private int tamanhoTelaPolegadas;
    private String tipoTela;

    public TV(String marca, String modelo, double preco, int tamanhoTelaPolegadas, String tipoTela) {
        super(marca, modelo, preco);
        this.tamanhoTelaPolegadas = tamanhoTelaPolegadas;
        this.tipoTela = tipoTela;
    }

    public int getTamanhoTelaPolegadas() {
        return tamanhoTelaPolegadas;
    }

    public void setTamanhoTelaPolegadas(int tamanhoTelaPolegadas) {
        this.tamanhoTelaPolegadas = tamanhoTelaPolegadas;
    }

    public String getTipoTela() {
        return tipoTela;
    }

    public void setTipoTela(String tipoTela) {
        this.tipoTela = tipoTela;
    }

    @Override
    public String toString() {
        return "TV - " + super.toString() + ", Tela: " + tamanhoTelaPolegadas + " polegadas, Tipo: " + tipoTela;
    }
}