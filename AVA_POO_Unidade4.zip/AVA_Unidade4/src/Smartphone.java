class Smartphone extends Produto {
    private String sistemaOperacional;
    private int armazenamentoGB;

    public Smartphone(String marca, String modelo, double preco, String sistemaOperacional, int armazenamentoGB) {
        super(marca, modelo, preco);
        this.sistemaOperacional = sistemaOperacional;
        this.armazenamentoGB = armazenamentoGB;
    }

    public String getSistemaOperacional() {
        return sistemaOperacional;
    }

    public void setSistemaOperacional(String sistemaOperacional) {
        this.sistemaOperacional = sistemaOperacional;
    }

    public int getArmazenamentoGB() {
        return armazenamentoGB;
    }

    public void voidsetArmazenamentoGB(int armazenamentoGB) {
        this.armazenamentoGB = armazenamentoGB;
    }

    @Override
    public String toString() {
        return "Smartphone - " + super.toString() + ", SO: " + sistemaOperacional + ", Armazenamento: " + armazenamentoGB + "GB";
    }
}
