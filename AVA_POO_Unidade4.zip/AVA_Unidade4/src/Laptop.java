class Laptop extends Produto {
    private String processador;
    private int memoriaRAMGB;

    public Laptop(String marca, String modelo, double preco, String processador, int memoriaRAMGB) {
        super(marca, modelo, preco);
        this.processador = processador;
        this.memoriaRAMGB = memoriaRAMGB;
    }

    public String getProcessador() {
        return processador;
    }

    public void setProcessador(String processador) {
        this.processador = processador;
    }

    public int getMemoriaRAMGB() {
        return memoriaRAMGB;
    }

    public void setMemoriaRAMGB(int memoriaRAMGB) {
        this.memoriaRAMGB = memoriaRAMGB;
    }

    @Override
    public String toString() {
        return "Laptop - " + super.toString() + ", Processador: " + processador + ", RAM: " + memoriaRAMGB + "GB";
    }
}