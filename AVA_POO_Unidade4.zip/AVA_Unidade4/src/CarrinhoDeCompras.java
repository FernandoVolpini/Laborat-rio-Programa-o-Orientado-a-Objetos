import java.util.ArrayList;
import java.util.List;

class CarrinhoDeCompras {
    private Cliente cliente;
    private final List<ItemCarrinho> itens;

    public CarrinhoDeCompras(Cliente cliente) {
        this.cliente = cliente;
        this.itens = new ArrayList<>();
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public List<ItemCarrinho> getItens() {
        return itens;
    }

    public void adicionarProduto(Produto produto, int quantidade) {
        if (quantidade <= 0) {
            System.out.println("Quantidade inválida para adicionar ao carrinho.");
            return;
        }
        for (ItemCarrinho item : itens) {
            if (item.getProduto().equals(produto)) {
                item.setQuantidade(item.getQuantidade() + quantidade);
                System.out.println(quantidade + " unidades de '" + produto.getModelo() + "' adicionadas ao carrinho.");
                return;
            }
        }
        itens.add(new ItemCarrinho(produto, quantidade));
        System.out.println(quantidade + " unidades de '" + produto.getModelo() + "' adicionadas ao carrinho.");
    }

    public void removerProduto(Produto produto) {
        itens.removeIf(item -> item.getProduto().equals(produto));
        System.out.println("Produto '" + produto.getModelo() + "' removido do carrinho.");
    }

    public double calcularTotal() {
        double total = 0;
        for (ItemCarrinho item : itens) {
            total += item.getSubtotal();
        }
        return total;
    }

    public void visualizarCarrinho() {
        System.out.println("\n--- Carrinho de Compras de " + cliente.getNome() + " ---");
        if (itens.isEmpty()) {
            System.out.println("O carrinho está vazio.");
            return;
        }
        for (ItemCarrinho item : itens) {
            System.out.println("- " + item);
        }
        System.out.println("Total a pagar: R$" + String.format("%.2f", calcularTotal()));
        System.out.println("------------------------------------");
    }
}