package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import model.Resultado;

public class CampeonatoDAO {

    private Connection con;
    private PreparedStatement cmd;

    public CampeonatoDAO() {
        con = Conexao.conectar();
    }

    public int inserir(Resultado r) {
        try {
            String SQL = "insert into tb_resultados(time1,time2,resultado1,"
                    + "resultado2) values (?,?,?,?)";
            cmd = con.prepareStatement(SQL, Statement.RETURN_GENERATED_KEYS);
            
            cmd.setString(1, r.getTime1());
            cmd.setString(2, r.getTime2());
            cmd.setInt(3, r.getResultado1());
            cmd.setInt(4, r.getResultado2());

            if (cmd.executeUpdate() > 0) {
                ResultSet rs = cmd.getGeneratedKeys();
                return rs.next() ? rs.getInt(1) : -1;
            }
            return -1;
        } catch (Exception e) {
            System.err.println("ERRO: " + e.getMessage());
            return -1;
        }
    }
    
    public List<Resultado> pesquisarResultado(String time){
        try {
            String SQL = "select * from tb_resultados" +
                " where time1 ilike ? or time2 ilike ?";
            cmd = con.prepareStatement(SQL);
            cmd.setString(1, "%"+time+"%");
            cmd.setString(2, "%"+time+"%");
            
            ResultSet rs = cmd.executeQuery();
            List<Resultado> lista = new ArrayList<>();
            while (rs.next()){
                lista.add(
                  new Resultado(
                    rs.getInt("id"),rs.getString("time1"),
                    rs.getString("time2"), rs.getInt("resultado1"),
                    rs.getInt("resultado2")
                  )
                );
            }
            return lista;
        } catch (Exception e) {
            System.err.println("ERRO: " + e.getMessage());
            return null;
        }
    }
    
}
