CREATE TABLE tb_resultados(
    id SERIAL PRIMARY KEY,
    time1 VARCHAR(100),
    time2 VARCHAR(100),
    resultado1 INT,
    resultado2 INT
);
